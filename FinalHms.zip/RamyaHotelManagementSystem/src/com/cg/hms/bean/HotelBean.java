package com.cg.hms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@NamedQuery(name="getAllHotels",query="select r from HotelBean r ORDER By r.hotelid")

@Table(name="hotel")
public class HotelBean {
	@Id
	@GeneratedValue/*(generator = "HotelIdseq", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="HotelIdseq" ,sequenceName="hotel_id_seq")*/
	
	@Column(name="hotel_id")
		private int hotelid;
	
	@Column(name="city")
		private String city;
	
	@Column(name="hotel_name")
		private String hotelname;
	
	@Column(name="address")
		private String address;
	
	@Column(name="description")
		private String description;
	
	@Column(name="avg_rate_per_night")
		private int avgratepernight;
	
	@Column(name="phone_no1")
		private String phoneno1;
	
	@Column(name="phone_no2")
		private String phoneno2;
	
	@Column(name="rating")
		private String rating;
	
	@Column(name="email")
		private String email;
	
	@Column(name="fax")
		private String fax;
	
	/**************************************************************************************
	 * generate getters and setters
	 ***************************************************************************************/

	public int getHotelid() {
		return hotelid;
	}
	public void setHotelid(int hotelid) {
		this.hotelid = hotelid;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getHotelname() {
		return hotelname;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getAvgratepernight() {
		return avgratepernight;
	}
	public void setAvgratepernight(int avgratepernight) {
		this.avgratepernight = avgratepernight;
	}
	
	public String getPhoneno1() {
		return phoneno1;
	}
	public void setPhoneno1(String phoneno1) {
		this.phoneno1 = phoneno1;
	}
	
	public String getPhoneno2() {
		return phoneno2;
	}
	public void setPhoneno2(String phoneno2) {
		this.phoneno2 = phoneno2;
	}
	
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	
	/**********************************************************************************
	 * parameterized constructor
	 * **********************************************************************************/
	public HotelBean() {
		// TODO Auto-generated constructor stub
	}
	public HotelBean(int hotelid, String city, String hotelname,
			String address, String description, int avgratepernight,
			String phoneno1, String phoneno2, String rating, String email,
			String fax) {
		super();
		this.hotelid = hotelid;
		this.city = city;
		this.hotelname = hotelname;
		this.address = address;
		this.description = description;
		this.avgratepernight = avgratepernight;
		this.phoneno1 = phoneno1;
		this.phoneno2 = phoneno2;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
	}
	@Override
	public String toString() {
		return "HotelBean [hotelid=" + hotelid + ", city=" + city
				+ ", hotelname=" + hotelname + ", address=" + address
				+ ", description=" + description + ", avgratepernight="
				+ avgratepernight + ", phoneno1=" + phoneno1 + ", phoneno2="
				+ phoneno2 + ", rating=" + rating + ", email=" + email
				+ ", fax=" + fax + "]";
	}

	
	
	
	

	




}
